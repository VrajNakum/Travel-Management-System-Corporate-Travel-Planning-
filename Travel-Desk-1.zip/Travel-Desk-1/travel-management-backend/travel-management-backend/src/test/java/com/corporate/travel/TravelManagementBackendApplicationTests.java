package com.corporate.travel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelManagementBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
