package com.corporate.travel.enums;

public enum ReimbursementStatus {
    PENDING,
    APPROVED,
    REJECTED,
    REIMBURSED
}
