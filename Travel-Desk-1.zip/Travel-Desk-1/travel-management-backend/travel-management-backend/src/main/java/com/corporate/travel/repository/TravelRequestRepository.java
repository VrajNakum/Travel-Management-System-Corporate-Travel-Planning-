package com.corporate.travel.repository;

import com.corporate.travel.entity.TravelRequest;
import com.corporate.travel.enums.RequestStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import java.util.List;

public interface TravelRequestRepository extends JpaRepository<TravelRequest, Long> {
    List<TravelRequest> findByEmployeeId(Long employeeId);
    List<TravelRequest> findByStatus(RequestStatus status);
}
