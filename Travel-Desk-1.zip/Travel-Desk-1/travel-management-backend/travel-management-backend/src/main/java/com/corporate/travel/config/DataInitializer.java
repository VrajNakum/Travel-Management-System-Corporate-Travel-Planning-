package com.corporate.travel.config;


import com.corporate.travel.entity.Department;
import com.corporate.travel.entity.TravelPolicy;
import com.corporate.travel.entity.User;
import com.corporate.travel.enums.Role;
import com.corporate.travel.enums.TravelClass;
import com.corporate.travel.repository.DepartmentRepository;
import com.corporate.travel.repository.TravelPolicyRepository;
import com.corporate.travel.repository.UserRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {
    private final DepartmentRepository departmentRepository;
    private final UserRepository userRepository;
    private final TravelPolicyRepository travelPolicyRepository;

    @Override
    @Transactional
    public void run(String... args) {
        if (departmentRepository.count() > 0) {
            log.info("Database already seeded. Skipping initialization.");
            return;
        }

        log.info("Seeding initial master data...");

        // 1. Create Departments
        Department engineering = departmentRepository.save(
                Department.builder().name("Engineering").build()
        );
        Department sales = departmentRepository.save(
                Department.builder().name("Sales").build()
        );
        Department financeDept = departmentRepository.save(
                Department.builder().name("Finance").build()
        );

        // 2. Create Users (with hierarchy)
        // Engineering Manager
        User managerBob = userRepository.save(
                User.builder()
                        .fullName("Bob Miller")
                        .email("bob.manager@company.com")
                        .role(Role.MANAGER)
                        .department(engineering)
                        .manager(null)
                        .build()
        );

        // Engineering Employee (Reports to Bob)
        userRepository.save(
                User.builder()
                        .fullName("Alice Johnson")
                        .email("alice.employee@company.com")
                        .role(Role.EMPLOYEE)
                        .department(engineering)
                        .manager(managerBob)
                        .build()
        );

        // Finance Officer
        userRepository.save(
                User.builder()
                        .fullName("Carol Davis")
                        .email("carol.finance@company.com")
                        .role(Role.FINANCE)
                        .department(financeDept)
                        .manager(null)
                        .build()
        );

        // System Admin
        userRepository.save(
                User.builder()
                        .fullName("Dave Wilson")
                        .email("dave.admin@company.com")
                        .role(Role.ADMIN)
                        .department(engineering)
                        .manager(null)
                        .build()
        );

        // 3. Create Travel Policies
        travelPolicyRepository.save(
                TravelPolicy.builder()
                        .department(engineering)
                        .maxBudgetLimit(new BigDecimal("2000.00"))
                        .allowedTravelClass(TravelClass.ECONOMY)
                        .build()
        );

        travelPolicyRepository.save(
                TravelPolicy.builder()
                        .department(sales)
                        .maxBudgetLimit(new BigDecimal("5000.00"))
                        .allowedTravelClass(TravelClass.BUSINESS)
                        .build()
        );

        log.info("Initial master data successfully loaded!");
    }
}
