package com.corporate.travel.controller;

import com.corporate.travel.dto.TravelRequestCreateDto;
import com.corporate.travel.dto.TravelRequestResponseDto;
import com.corporate.travel.service.TravelRequestService;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/travel-requests")
public class TravelRequestController {

    private final TravelRequestService travelRequestService;

    // Explicit constructor injection
    public TravelRequestController(TravelRequestService travelRequestService) {
        this.travelRequestService = travelRequestService;
    }

    @PostMapping
    public ResponseEntity<TravelRequestResponseDto> createTravelRequest(@Valid @RequestBody TravelRequestCreateDto dto) {
        TravelRequestResponseDto created = travelRequestService.createTravelRequest(dto);
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<TravelRequestResponseDto> getTravelRequestById(@PathVariable Long id) {
        return ResponseEntity.ok(travelRequestService.getTravelRequestById(id));
    }

    @GetMapping("/employee/{employeeId}")
    public ResponseEntity<List<TravelRequestResponseDto>> getTravelRequestsByEmployee(@PathVariable Long employeeId) {
        return ResponseEntity.ok(travelRequestService.getTravelRequestsByEmployee(employeeId));
    }

    @GetMapping
    public ResponseEntity<List<TravelRequestResponseDto>> getAllTravelRequests() {
        return ResponseEntity.ok(travelRequestService.getAllTravelRequests());
    }
}