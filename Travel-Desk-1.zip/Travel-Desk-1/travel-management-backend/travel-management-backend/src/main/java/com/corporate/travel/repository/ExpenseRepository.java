package com.corporate.travel.repository;

import com.corporate.travel.entity.Expense;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

public interface ExpenseRepository extends JpaRepository<Expense, Long> {
    List<Expense> findByTravelRequestId(Long travelRequestId);
}
