package com.corporate.travel.enums;

public enum TravelClass {
    ECONOMY,
    PREMIUM_ECONOMY,
    BUSINESS
}
