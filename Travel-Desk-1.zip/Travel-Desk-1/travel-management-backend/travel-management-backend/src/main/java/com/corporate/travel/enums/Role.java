package com.corporate.travel.enums;

//Why the Errors Happened
//1. The Immediate Cause: Declared as class instead of enum


public enum Role {
    EMPLOYEE,
    MANAGER,
    FINANCE,
    ADMIN
}
