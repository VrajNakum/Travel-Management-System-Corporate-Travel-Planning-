package com.corporate.travel.repository;

import com.corporate.travel.entity.ItinerarySegment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

public interface ItinerarySegmentRepository extends JpaRepository<ItinerarySegment, Long> {
    List<ItinerarySegment> findByTravelRequestIdOrderByStartTimeAsc(Long travelRequestId);
}
