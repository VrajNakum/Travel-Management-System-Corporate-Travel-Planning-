package com.corporate.travel.enums;

public enum SegmentType {
    FLIGHT,
    TRAIN,
    HOTEL,
    CAB,
    BUS
}
