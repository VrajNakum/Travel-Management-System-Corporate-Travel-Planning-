package com.corporate.travel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelManagementBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelManagementBackendApplication.class, args);
	}

}
