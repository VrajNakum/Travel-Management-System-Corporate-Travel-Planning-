package com.corporate.travel.service;

import com.corporate.travel.dto.TravelRequestCreateDto;
import com.corporate.travel.dto.TravelRequestResponseDto;

import java.util.List;

public interface TravelRequestService {
    TravelRequestResponseDto createTravelRequest(TravelRequestCreateDto dto);
    TravelRequestResponseDto getTravelRequestById(Long id);
    List<TravelRequestResponseDto> getTravelRequestsByEmployee(Long employeeId);
    List<TravelRequestResponseDto> getAllTravelRequests();
}
