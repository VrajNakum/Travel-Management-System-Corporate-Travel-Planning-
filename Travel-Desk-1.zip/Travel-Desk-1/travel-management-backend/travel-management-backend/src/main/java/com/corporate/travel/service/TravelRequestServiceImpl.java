package com.corporate.travel.service;

import com.corporate.travel.dto.TravelRequestCreateDto;
import com.corporate.travel.dto.TravelRequestResponseDto;
import com.corporate.travel.entity.Department;
import com.corporate.travel.entity.TravelPolicy;
import com.corporate.travel.entity.TravelRequest;
import com.corporate.travel.entity.User;
import com.corporate.travel.enums.RequestStatus;
import com.corporate.travel.enums.TravelClass;
import com.corporate.travel.exception.ResourceNotFoundException;
import com.corporate.travel.repository.TravelPolicyRepository;
import com.corporate.travel.repository.TravelRequestRepository;
import com.corporate.travel.repository.UserRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TravelRequestServiceImpl implements TravelRequestService {

    private final TravelRequestRepository travelRequestRepository;
    private final UserRepository userRepository;
    private final TravelPolicyRepository travelPolicyRepository;

    // Explicit constructor injection (SonarQube compliant & zero Lombok dependency)
    public TravelRequestServiceImpl(
            TravelRequestRepository travelRequestRepository,
            UserRepository userRepository,
            TravelPolicyRepository travelPolicyRepository) {
        this.travelRequestRepository = travelRequestRepository;
        this.userRepository = userRepository;
        this.travelPolicyRepository = travelPolicyRepository;
    }

    @Override
    @Transactional
    public TravelRequestResponseDto createTravelRequest(TravelRequestCreateDto dto) {
        User employee = userRepository.findById(dto.getEmployeeId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + dto.getEmployeeId()));

        // Validate Date Order
        if (dto.getEndDate().isBefore(dto.getStartDate())) {
            throw new IllegalArgumentException("End date cannot be earlier than start date");
        }

        // Determine Initial Status (DRAFT vs PENDING_MANAGER)
        RequestStatus initialStatus = dto.isDraft() ? RequestStatus.DRAFT : RequestStatus.PENDING_MANAGER;

        // Run Policy Enforcement Engine
        PolicyCheckResult policyResult = checkPolicy(employee.getDepartment(), dto);

        TravelRequest travelRequest = TravelRequest.builder()
                .employee(employee)
                .destination(dto.getDestination())
                .startDate(dto.getStartDate())
                .endDate(dto.getEndDate())
                .purpose(dto.getPurpose())
                .estimatedBudget(dto.getEstimatedBudget())
                .travelClass(dto.getTravelClass())
                .status(initialStatus)
                .policyViolated(policyResult.isViolated())
                .policyViolationReason(policyResult.getReason())
                .build();

        TravelRequest saved = travelRequestRepository.save(travelRequest);
        return mapToDto(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public TravelRequestResponseDto getTravelRequestById(Long id) {
        TravelRequest request = travelRequestRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Travel request not found with id: " + id));
        return mapToDto(request);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TravelRequestResponseDto> getTravelRequestsByEmployee(Long employeeId) {
        return travelRequestRepository.findByEmployeeId(employeeId)
                .stream()
                .map(this::mapToDto)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<TravelRequestResponseDto> getAllTravelRequests() {
        return travelRequestRepository.findAll()
                .stream()
                .map(this::mapToDto)
                .toList();
    }

    // Policy Check Logic (Core Feature 3)
    private PolicyCheckResult checkPolicy(Department department, TravelRequestCreateDto dto) {
        Optional<TravelPolicy> policyOpt = travelPolicyRepository.findByDepartmentId(department.getId());
        if (policyOpt.isEmpty()) {
            return new PolicyCheckResult(false, null);
        }

        TravelPolicy policy = policyOpt.get();
        List<String> violations = new ArrayList<>();

        // 1. Budget Limit Check
        if (dto.getEstimatedBudget().compareTo(policy.getMaxBudgetLimit()) > 0) {
            violations.add(String.format("Estimated budget ($%s) exceeds department limit ($%s)",
                    dto.getEstimatedBudget(), policy.getMaxBudgetLimit()));
        }

        // 2. Allowed Travel Class Check (BUSINESS > PREMIUM_ECONOMY > ECONOMY)
        if (isClassHigherThanAllowed(dto.getTravelClass(), policy.getAllowedTravelClass())) {
            violations.add(String.format("Requested travel class [%s] exceeds allowed class [%s]",
                    dto.getTravelClass(), policy.getAllowedTravelClass()));
        }

        if (!violations.isEmpty()) {
            return new PolicyCheckResult(true, String.join("; ", violations));
        }

        return new PolicyCheckResult(false, null);
    }

    private boolean isClassHigherThanAllowed(TravelClass requested, TravelClass allowed) {
        return requested.ordinal() > allowed.ordinal();
    }

    private TravelRequestResponseDto mapToDto(TravelRequest entity) {
        return TravelRequestResponseDto.builder()
                .id(entity.getId())
                .employeeId(entity.getEmployee().getId())
                .employeeName(entity.getEmployee().getFullName())
                .departmentName(entity.getEmployee().getDepartment().getName())
                .destination(entity.getDestination())
                .startDate(entity.getStartDate())
                .endDate(entity.getEndDate())
                .purpose(entity.getPurpose())
                .estimatedBudget(entity.getEstimatedBudget())
                .travelClass(entity.getTravelClass())
                .status(entity.getStatus())
                .policyViolated(entity.getPolicyViolated())
                .policyViolationReason(entity.getPolicyViolationReason())
                .createdAt(entity.getCreatedAt())
                .updatedAt(entity.getUpdatedAt())
                .build();
    }

    // Inner helper class for policy check outcome
    private static class PolicyCheckResult {
        private final boolean violated;
        private final String reason;

        public PolicyCheckResult(boolean violated, String reason) {
            this.violated = violated;
            this.reason = reason;
        }

        public boolean isViolated() {
            return violated;
        }

        public String getReason() {
            return reason;
        }
    }
}