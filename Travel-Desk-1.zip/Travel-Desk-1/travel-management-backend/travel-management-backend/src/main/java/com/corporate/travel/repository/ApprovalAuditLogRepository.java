package com.corporate.travel.repository;

import com.corporate.travel.entity.ApprovalAuditLog;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

public interface ApprovalAuditLogRepository extends JpaRepository<ApprovalAuditLog, Long> {
    List<ApprovalAuditLog> findByTravelRequestIdOrderByActionTimestampDesc(Long travelRequestId);
}
